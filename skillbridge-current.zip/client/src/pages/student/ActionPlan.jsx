import { useState, useEffect, useRef } from 'react'
import {
  Rocket, BookOpen, FolderKanban, Award, User,
  ExternalLink, ChevronRight, Zap, TrendingUp, Star
} from 'lucide-react'
import { studentService } from '../../services/api'

const ROLES = [
  'Full Stack Developer', 'Frontend Developer', 'Backend Developer',
  'Data Scientist', 'ML Engineer', 'Data Engineer',
  'DevOps Engineer', 'Mobile Developer', 'Android Developer',
  'iOS Developer', 'UI/UX Designer', 'Cybersecurity Analyst',
]

// Category metadata
const CAT_META = {
  skill:   { icon: BookOpen,     color: 'sky',     bg: 'bg-sky-500',     label: 'Learn'         },
  project: { icon: FolderKanban, color: 'violet',  bg: 'bg-violet-500',  label: 'Build'         },
  cert:    { icon: Award,        color: 'amber',   bg: 'bg-amber-500',   label: 'Certify'       },
  profile: { icon: User,         color: 'emerald', bg: 'bg-emerald-500', label: 'Profile'       },
}

// Type → priority label
const TYPE_LABEL = {
  'missing-core':   { text: 'Required',  cls: 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 border-red-200 dark:border-red-800' },
  'missing-strong': { text: 'Important', cls: 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800' },
  'upgrade':        { text: 'Level Up',  cls: 'bg-sky-100 dark:bg-sky-900/30 text-sky-600 dark:text-sky-400 border-sky-200 dark:border-sky-800' },
  'project':        { text: 'Portfolio', cls: 'bg-violet-100 dark:bg-violet-900/30 text-violet-600 dark:text-violet-400 border-violet-200 dark:border-violet-800' },
  'cert':           { text: 'Credential', cls: 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800' },
  'profile':        { text: 'Quick Win', cls: 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800' },
}

const TAG_COLORS = {
  Free:     'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300',
  Paid:     'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400',
  Docs:     'bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300',
  Guide:    'bg-violet-100 dark:bg-violet-900/40 text-violet-600 dark:text-violet-300',
  Ideas:    'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300',
  Internal: 'bg-sky-100 dark:bg-sky-900/40 text-sky-600 dark:text-sky-300',
}

// Group steps into phases for display
const PHASE_ORDER = ['missing-core', 'upgrade', 'missing-strong', 'project', 'cert', 'profile']
const PHASE_TITLES = {
  'missing-core':   { title: 'Must-Learn Skills',           icon: Zap,        desc: 'These skills are listed as requirements in most job postings for this role.' },
  'upgrade':        { title: 'Deepen What You Know',        icon: TrendingUp, desc: 'You already have these — going deeper sets you apart from other candidates.' },
  'missing-strong': { title: 'Skills to Pick Up Next',      icon: Star,       desc: 'Not blocking, but expected by most interviewers.' },
  'project':        { title: 'Build Your Portfolio',        icon: FolderKanban, desc: 'A real project is the most convincing thing you can show a recruiter.' },
  'cert':           { title: 'Earn a Certification',        icon: Award,      desc: 'Adds credibility especially for campus placements and first jobs.' },
  'profile':        { title: 'Quick Profile Win',           icon: User,       desc: 'Takes 5 minutes and makes your profile show up in more employer searches.' },
}

function CourseLink({ res }) {
  const tagCls = TAG_COLORS[res.tag] || TAG_COLORS.Free
  return (
    <a
      href={res.url}
      target={res.url.startsWith('/') ? '_self' : '_blank'}
      rel="noreferrer"
      className="group flex items-center justify-between gap-3 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 hover:border-brand-300 dark:hover:border-brand-600 hover:bg-white dark:hover:bg-slate-800 transition-all"
    >
      <div className="flex items-center gap-2 min-w-0">
        <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-brand-500 transition-colors flex-shrink-0" />
        <span className="text-sm font-medium text-slate-700 dark:text-slate-200 group-hover:text-slate-900 dark:group-hover:text-white transition-colors truncate">
          {res.label}
        </span>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        {res.tag && (
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${tagCls}`}>
            {res.tag}
          </span>
        )}
        <ChevronRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-brand-400 transition-colors" />
      </div>
    </a>
  )
}

function StepCard({ step, index }) {
  const [open, setOpen] = useState(index < 2) // first 2 open by default
  const meta = CAT_META[step.category] || CAT_META.skill
  const Icon = meta.icon
  const typeBadge = TYPE_LABEL[step.type]

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
      {/* Header — always visible, clickable to expand */}
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center gap-4 p-5 text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
      >
        {/* Icon */}
        <div className={`w-10 h-10 rounded-xl ${meta.bg} flex items-center justify-center flex-shrink-0`}>
          <Icon className="w-4.5 h-4.5 text-white" />
        </div>

        {/* Title + badge */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-bold text-slate-800 dark:text-white">{step.title}</span>
            {typeBadge && (
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${typeBadge.cls}`}>
                {typeBadge.text}
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 leading-snug line-clamp-1">
            {step.why}
          </p>
        </div>

        {/* Expand arrow */}
        <ChevronRight className={`w-4 h-4 text-slate-400 flex-shrink-0 transition-transform ${open ? 'rotate-90' : ''}`} />
      </button>

      {/* Body — courses */}
      {open && (
        <div className="px-5 pb-5 space-y-2">
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-3">
            {step.why}
          </p>
          {step.courses?.length > 0 ? (
            <div className="space-y-2">
              {step.courses.map((res, i) => (
                <CourseLink key={i} res={res} />
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-400 italic">No resources found for this skill.</p>
          )}
        </div>
      )}
    </div>
  )
}

function PhaseSection({ type, steps }) {
  const phaseMeta = PHASE_TITLES[type]
  if (!phaseMeta || steps.length === 0) return null
  const PhaseIcon = phaseMeta.icon

  return (
    <div className="space-y-3">
      {/* Phase header */}
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 rounded-xl bg-brand-50 dark:bg-brand-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
          <PhaseIcon className="w-4 h-4 text-brand-500" />
        </div>
        <div>
          <h3 className="text-sm font-bold text-slate-800 dark:text-white">{phaseMeta.title}</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{phaseMeta.desc}</p>
        </div>
      </div>

      {/* Step cards */}
      <div className="space-y-2 pl-11">
        {steps.map((step, i) => (
          <StepCard key={step.id} step={step} index={i} />
        ))}
      </div>
    </div>
  )
}

export default function ActionPlan() {
  const [role, setRole]     = useState(ROLES[0])
  const [data, setData]     = useState(null)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy]     = useState(false)
  const [error, setError]   = useState('')
  const mountedRef = useRef(true)

  useEffect(() => {
    mountedRef.current = true
    return () => { mountedRef.current = false }
  }, [])

  const load = async (r, initial = false) => {
    if (!initial) setBusy(true)
    setError('')
    try {
      const res = await studentService.getActionPlan(r)
      if (mountedRef.current) setData(res.data)
    } catch {
      if (mountedRef.current) setError('Could not load action plan. Please try again.')
    } finally {
      if (mountedRef.current) { setLoading(false); setBusy(false) }
    }
  }

  useEffect(() => { load(role, true) }, []) // eslint-disable-line

  const changeRole = r => {
    if (r === role || busy) return
    setRole(r)
    load(r)
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <svg className="animate-spin w-8 h-8 text-brand-500" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
      </svg>
    </div>
  )

  if (error) return (
    <div className="flex flex-col items-center justify-center h-64 gap-3">
      <p className="text-red-500 font-medium">{error}</p>
      <button onClick={() => load(role, true)}
        className="px-4 py-2 bg-brand-500 text-white rounded-xl text-sm font-semibold hover:bg-brand-600 transition-colors">
        Retry
      </button>
    </div>
  )

  const steps = data?.steps || []

  // Group steps by type, in display order
  const grouped = {}
  PHASE_ORDER.forEach(type => {
    grouped[type] = steps.filter(s => s.type === type)
  })

  const hasAnyStep = steps.length > 0

  return (
    <div className="space-y-6 max-w-3xl mx-auto">

      {/* Role selector card */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5">
        <div className="flex items-center gap-2 mb-1">
          <Rocket className="w-4 h-4 text-brand-500" />
          <span className="text-sm font-bold text-slate-800 dark:text-white">Learning Roadmap</span>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
          Pick a target role to see the most important things to learn next — with direct links to the best courses.
        </p>
        <div className="flex flex-wrap gap-2">
          {ROLES.map(r => (
            <button key={r} onClick={() => changeRole(r)} disabled={busy}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all disabled:opacity-60 ${
                role === r
                  ? 'bg-brand-500 border-brand-500 text-white shadow-sm'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-brand-300 dark:hover:border-brand-600 hover:text-slate-800 dark:hover:text-white'
              }`}>
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className={`space-y-8 transition-opacity duration-200 ${busy ? 'opacity-40 pointer-events-none' : ''}`}>

        {busy && (
          <div className="flex items-center justify-center h-24">
            <svg className="animate-spin w-6 h-6 text-brand-500" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
            </svg>
          </div>
        )}

        {!busy && hasAnyStep && PHASE_ORDER.map(type => (
          <PhaseSection key={type} type={type} steps={grouped[type] || []} />
        ))}

        {!busy && !hasAnyStep && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-12 text-center">
            <div className="w-14 h-14 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Rocket className="w-7 h-7 text-emerald-500" />
            </div>
            <p className="font-bold text-slate-700 dark:text-slate-200 text-base">You're well-prepared!</p>
            <p className="text-sm text-slate-400 mt-2 max-w-sm mx-auto">
              No major gaps for this role. Check your Readiness Score for the full breakdown.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}